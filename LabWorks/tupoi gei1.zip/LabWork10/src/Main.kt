import kotlinx.coroutines.*

suspend fun main() = coroutineScope<Unit>{
        println("Поток - ${Thread.currentThread()}")
    launch {
        sheep()
    }
    launch {
        cat()
    }
}

suspend fun sheep(){
    for (i in 1..500)
        println("$i - овечка с именем ${Thread.currentThread()}")
    delay(1000L)
    for (i in 501..1000)
        println("$i - овечка с именем ${Thread.currentThread()}")
}

suspend fun cat(){
    for (i in 1..500) {
        println("$i - котик с именем ${Thread.currentThread()}")
        delay(10L)
    }
}