import kotlinx.coroutines.*

suspend fun main() = coroutineScope<Unit>{
    try {
        withTimeout(10000L) {
            connect()
        }
    }
    catch (e: TimeoutCancellationException)
    {
        println("Превышено время ожидания")
    }
}

suspend fun connect(){
        for (i in 1..5) {
            println("Попытка подключения к БД #$i")
            delay(3000L)
        }

        println("Подключились к БД")
}