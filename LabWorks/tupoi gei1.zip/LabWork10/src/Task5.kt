import kotlinx.coroutines.*
import kotlin.random.Random

suspend fun main() = coroutineScope<Unit>{
    val deffered : Deferred<Int> = async { connectWeb() }
    println("Code: ${deffered.await()}")
}

suspend fun connectWeb(): Int {
    println("Подключение к веб-серверу")
    delay(1000L)
    return when (Random.nextInt(1, 7)) {
        1 -> 200
        2 -> 400
        3 -> 401
        4 -> 403
        5 -> 404
        6 -> 410
        else -> 500
    }
}