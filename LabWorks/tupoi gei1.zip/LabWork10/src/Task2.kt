import kotlinx.coroutines.*

suspend fun main() = coroutineScope<Unit>{
    val job : Job = launch(Dispatchers.IO){
        load()
    }
    if (readln() == "cancel")
        job.cancelAndJoin()
}

suspend fun load(){
    try{
    for (n in 1..30)
    {
        println("Загрузка файла $n.txt")
        delay(3000L)
    }
        println("Все файлы загружены")
    }
    catch (e: CancellationException)
    {
        println("Загрузка отменена")
    }
}