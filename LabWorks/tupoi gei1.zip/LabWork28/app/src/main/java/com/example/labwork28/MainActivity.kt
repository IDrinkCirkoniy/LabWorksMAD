package com.example.labwork28

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.text.isDigitsOnly
import com.example.labwork28.ui.theme.LabWork28Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var currentScreen by remember { mutableStateOf("books") }
            Main(currentScreen,
                {
                    currentScreen = "books"
                },
                {
                    currentScreen = "add"
                },
                {
                    currentScreen = "update"
                })
        }
    }
}

@Composable
fun Main(screen: String, goToBooksScreen: () -> Unit, goToAddScreen: () -> Unit, goToUpdateScreen: () -> Unit) {
    var currentBook by remember { mutableStateOf(0) }

    LabWork28Theme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            when (screen) {
                "books" -> BooksScreen(
                    modifier = Modifier.padding(innerPadding),
                    goToAddScreen = goToAddScreen,
                    goToUpdateScreen = goToUpdateScreen,
                    changeCurrentBook = {id : Int -> currentBook = id}
                )

                "add" -> AddScreen(
                    modifier = Modifier.padding(innerPadding),
                    goToBooksScreen = goToBooksScreen,
                )

                "update" -> UpdateScreen(
                    modifier = Modifier.padding(innerPadding),
                    goToBooksScreen = goToBooksScreen,
                    bookId = currentBook
                )

                else -> goToBooksScreen()
            }
        }
    }
}

@Composable
fun BooksScreen(modifier: Modifier, goToAddScreen: () -> Unit, goToUpdateScreen: () -> Unit, changeCurrentBook: (Int)->Unit) {
    var db = DbHandler(LocalContext.current)



    var booksList by remember { mutableStateOf(db.getBooks()) }


    Column(
        modifier
            .fillMaxSize()
    ) {
        Button({goToAddScreen()}) {
            Text("Добавить книгу")
        }
        LazyColumn() {
            items(booksList) { book ->
                Text("Название: ${book.name}")
                Text("Автор: ${book.author}")
                Text("Год: ${book.year.toString()}")
                Text("Количество страниц: ${book.pagesCount.toString()}")
                Button({
                    db.deleteBook(book.id)
                    booksList = db.getBooks()
                }) {
                    Text("Удалить")
                }
                Button({
                    changeCurrentBook(book.id)
                    goToUpdateScreen()}) {
                    Text("Обновить")
                }
                Spacer(Modifier.size(10.dp))
            }
        }
    }
}

@Composable
fun AddScreen(modifier: Modifier, goToBooksScreen: () -> Unit) {
    var db = DbHandler(LocalContext.current)

    var name by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var pagesCount by remember { mutableStateOf("") }

    Column(modifier.fillMaxSize()) {
        Button({goToBooksScreen()}) {
            Text("Назад")
        }
        OutlinedTextField(name, { name = it }, label = { Text("Название") })
        OutlinedTextField(author, { author = it }, label = { Text("Автор") })
        OutlinedTextField(year, { year = it }, label = { Text("Год") })
        OutlinedTextField(pagesCount, { pagesCount = it }, label = { Text("Количество страниц") })

        Button({
            if (name.isNotEmpty() && author.isNotEmpty() && year.isDigitsOnly() && pagesCount.isDigitsOnly() && year.isNotEmpty() && pagesCount.isNotEmpty()) {
                db.addBook(name, author, year.toInt(), pagesCount.toInt())
                goToBooksScreen()
            }
        }) {
            Text("Добавить")
        }


    }
}

@Composable
fun UpdateScreen(modifier: Modifier, goToBooksScreen: () -> Unit, bookId:Int) {
    var db = DbHandler(LocalContext.current)

    var book = db.getBooks().first({ it.id == bookId })

    var name by remember { mutableStateOf(book.name) }
    var author by remember { mutableStateOf(book.author) }
    var year by remember { mutableStateOf(book.year.toString()) }
    var pagesCount by remember { mutableStateOf(book.pagesCount.toString()) }

    Column(modifier.fillMaxSize()) {
        Button({goToBooksScreen()}) {
            Text("Назад")
        }
        OutlinedTextField(name, { name = it }, label = { Text("Название") })
        OutlinedTextField(author, { author = it }, label = { Text("Автор") })
        OutlinedTextField(year, { year = it }, label = { Text("Год") })
        OutlinedTextField(pagesCount, { pagesCount = it }, label = { Text("Количество страниц") })

        Button({
            db.updateBook(bookId,name, author, year.toInt(), pagesCount.toInt())
            goToBooksScreen()
        }) {
            Text("Обновить")
        }
    }
}