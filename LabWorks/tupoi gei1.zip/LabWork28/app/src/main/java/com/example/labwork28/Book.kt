package com.example.labwork28

class Book(val id :Int ,val name : String, val author: String, val year : Int, val pagesCount: Int)