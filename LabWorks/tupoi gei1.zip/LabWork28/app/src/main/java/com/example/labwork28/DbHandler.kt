package com.example.labwork28

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbHandler(context: Context)
    : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        val query = ("CREATE TABLE " + BOOKS_TABLE + "("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT NOT NULL, "
                + AUTHOR_COL + " TEXT NOT NULL, "
                + YEAR_COL + " INTEGER NOT NULL, "
                + PAGESCOUNT_COL + " INTEGER NOT NULL )")

        db.execSQL(query)
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        db.execSQL("DROP TABLE IF EXISTS $BOOKS_TABLE")

        onCreate(db)
    }

    fun addBook(name: String, author: String, year: Int, pagesCount: Int) {
        val db = this.writableDatabase

        val values = ContentValues()
        values.put(NAME_COL, name)
        values.put(AUTHOR_COL, author)
        values.put(YEAR_COL, year)
        values.put(PAGESCOUNT_COL, pagesCount)

        db.insert(BOOKS_TABLE, null, values)

        db.close()
    }

    fun deleteBook(id: Int) {
        val db = this.writableDatabase
        val selection = "id = ?"
        val selectionArgs = arrayOf(id.toString())

        db.delete(BOOKS_TABLE, selection, selectionArgs)
    }

    fun updateBook(id: Int, name: String, author: String, year: Int, pagesCount: Int) {
        val db = this.writableDatabase

        val values = ContentValues()
        values.put(NAME_COL, name)
        values.put(AUTHOR_COL, author)
        values.put(YEAR_COL, year)
        values.put(PAGESCOUNT_COL, pagesCount)

        db.update(BOOKS_TABLE, values, "id = ?", arrayOf(id.toString()))
    }

    fun getBooks(): List<Book> {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $BOOKS_TABLE", null)

        val usersArrayList: ArrayList<Book> = ArrayList()

        cursor.use {
            if (cursor.moveToFirst()) {
                do {
                    usersArrayList.add(
                        Book(
                            cursor.getInt(0),
                            cursor.getString(1),
                            cursor.getString(2),
                            cursor.getInt(3),
                            cursor.getInt(4),
                        )
                    )


                } while (cursor.moveToNext())
            }
            db.close()
            return usersArrayList
        }
    }

    companion object {
        private const val DB_NAME = "books_db"
        private const val DB_VERSION = 1
        private const val BOOKS_TABLE = "book"
        private const val ID_COL = "id"
        private const val NAME_COL = "name"
        private const val AUTHOR_COL = "author"
        private const val YEAR_COL = "year"
        private const val PAGESCOUNT_COL = "pagescount"
    }
}