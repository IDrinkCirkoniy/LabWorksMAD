package com.example.labwork23.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

@Composable
fun TaskAddScreen(modifier: Modifier, onClickAdd: () -> Unit){
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    Column(modifier) {
        TextField(name, {name = it}, label = { Text("Название задачи") })
        TextField(description, {description = it}, label = { Text("Описание задачи") })
        Button({onClickAdd()}) {
            Text("Добавить задачу")
        }
    }




}