package com.example.labwork23.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign

@Composable
fun RemoveTaskScreen(modifier: Modifier, onClickRemove: () -> Unit){
    var isConfirmed by remember { mutableStateOf(false) }

    Column(modifier) {
        Text("Задача")
        Row(){
            Checkbox(isConfirmed, {isConfirmed = !isConfirmed})
            Text("Вы уверены, что хотите удалить задачу?", textAlign = TextAlign.Left,modifier= Modifier.fillMaxWidth().align(Alignment.CenterVertically))
        }
        Button({onClickRemove()}, enabled = isConfirmed) {
            Text("Удалить")
        }

    }


}