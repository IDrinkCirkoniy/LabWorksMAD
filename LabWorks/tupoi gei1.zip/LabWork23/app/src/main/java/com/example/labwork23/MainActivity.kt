package com.example.labwork23

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.labwork23.screens.MainScreen
import com.example.labwork23.screens.RemoveTaskScreen
import com.example.labwork23.screens.TaskAddScreen
import com.example.labwork23.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var isDark by remember { mutableStateOf(false) }
            var isChangedScheme by remember { mutableStateOf(false) }
            AppTheme(darkTheme = isDark, isChangedScheme = isChangedScheme) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = { Text("Задачи") },
                            navigationIcon = {
                                IconButton({}) {
                                    Icon(Icons.Filled.Menu, "Menu")
                                }
                            },
                            actions = {
                                IconButton({ isDark = !isDark }) {
                                    Icon(Icons.Default.Settings, "Dark")
                                }
                                IconButton({ isChangedScheme = !isChangedScheme }) {
                                    Icon(Icons.Default.Warning, "Scheme")
                                }
                            }
                        )
                    }) { innerPadding ->
                    Navigate(Modifier.padding(innerPadding).fillMaxSize())
                }
            }
        }
    }
}

@Composable
fun Navigate(modifier: Modifier){
    var screen by remember { mutableStateOf("home") }

    if(screen == "home") {
        MainScreen(modifier, {screen = "remove"}, {screen = "add"})
    }
    if(screen == "add")
    {
        TaskAddScreen(modifier, {screen = "home"})
    }
    if (screen == "remove")
    {
        RemoveTaskScreen(modifier, {screen = "home"})
    }
}