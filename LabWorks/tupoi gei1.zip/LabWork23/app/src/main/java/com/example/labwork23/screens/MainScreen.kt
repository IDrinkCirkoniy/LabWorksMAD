package com.example.labwork23.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign

@Composable
fun MainScreen(modifier: Modifier, onClickRemove: () -> Unit, onClickAdd: () -> Unit ){
    var firstTask by remember { mutableStateOf(false) }
    var secondTask by remember { mutableStateOf(false) }
    var thirdTask by remember { mutableStateOf(false) }

    Column(modifier) {
        Button({onClickAdd()}, Modifier.align(Alignment.CenterHorizontally)) {
            Text("Добавить задачу")
        }
     Row(){
         Checkbox(firstTask, {firstTask = !firstTask})
         Text("Первая задача", textAlign = TextAlign.Left,modifier= Modifier.fillMaxWidth(0.9f).align(Alignment.CenterVertically))
         IconButton({onClickRemove()}) {
             Icon(Icons.Default.Delete, "Delete")
         }
     }
        Row(){
            Checkbox(secondTask, {secondTask = !secondTask})
            Text("Вторая задача", textAlign = TextAlign.Left,modifier= Modifier.fillMaxWidth(0.9f).align(Alignment.CenterVertically))
            IconButton({onClickRemove()}) {
                Icon(Icons.Default.Delete, "Delete")
            }
        }
        Row(){
            Checkbox(thirdTask, {thirdTask = !thirdTask})
            Text("Третья задача", textAlign = TextAlign.Left,modifier= Modifier.fillMaxWidth(0.9f).align(Alignment.CenterVertically))
            IconButton({onClickRemove()}) {
                Icon(Icons.Default.Delete, "Delete")
            }
        }
    }
}