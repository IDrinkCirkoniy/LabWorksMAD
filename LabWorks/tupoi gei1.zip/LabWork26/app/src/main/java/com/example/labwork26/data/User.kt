package com.example.labwork26.data

import androidx.room3.ColumnInfo
import androidx.room3.PrimaryKey
import org.jetbrains.annotations.NotNull


data class User(val login: String, var password: String, var email: String)