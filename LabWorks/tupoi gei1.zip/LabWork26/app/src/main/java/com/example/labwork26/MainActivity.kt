package com.example.labwork26

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.labwork26.ui.theme.LabWork26Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var screen by remember { mutableStateOf("user") }

            Main(screen,
                { screen = "add" },
                { screen = "change" },
                { screen = "profile" },
                { screen = "user" })

        }
    }
}

@Composable
fun Main(screen: String, goToAddScreen: () -> Unit, goToChangeScreen: () -> Unit, goToProfileScreen: () -> Unit, goToUserScreen: () -> Unit) {
    var login by remember { mutableStateOf("") }
    LabWork26Theme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            when (screen) {
                "user" -> UserScreen(
                    modifier = Modifier.padding(innerPadding),
                    goToChangeScreen = goToChangeScreen,
                    goToProfileScreen = goToProfileScreen,
                    goToAddScreen = goToAddScreen,
                    setCurrentLogin = {newLogin: String -> login = newLogin }
                )

                "add" -> AddScreen(
                    modifier = Modifier.padding(innerPadding),
                    goToUserScreen = goToUserScreen
                )

                "profile" -> ProfileScreen(
                    modifier = Modifier.padding(innerPadding),
                    goToUserScreen = goToUserScreen,
                )

                "change" -> ChangeScreen(
                    modifier = Modifier.padding(innerPadding),
                    goToUserScreen = goToUserScreen,
                )

                else -> goToUserScreen()
            }
        }
    }
}

@Composable
fun UserScreen(modifier: Modifier, vm: UserViewModel = viewModel(), goToAddScreen: () -> Unit, goToProfileScreen: () -> Unit, goToChangeScreen: () -> Unit, setCurrentLogin: (login : String) -> Unit) {
    Column() {
        Button({ goToAddScreen() }, modifier = Modifier.size(100.dp)) {
            Text("Добавить")
        }
        LazyColumn(Modifier.fillMaxWidth()) {
            items(vm.users) { user ->
                Text(user.login)
                IconButton({
                    vm.login = user.login
                    vm.email = user.email
                    vm.password = user.password
                    goToProfileScreen()
                }) {
                    Icon(Icons.Default.AccountCircle, "")
                }
                IconButton({
                    vm.removeUserByLogin(user.login)
                }) {
                    Icon(Icons.Default.Delete, "")
                }
            }
        }
    }
}


@Composable
fun AddScreen(modifier: Modifier, vm: UserViewModel = viewModel(), goToUserScreen: () -> Unit) {
    var login by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(modifier) {
        Button({ goToUserScreen() }) {
            Text("Назад")
        }
        TextField(value = login, { login = it }, placeholder = { Text("Логин") })
        TextField(value = email, { email = it }, placeholder = { Text("Почта") })
        TextField(value = password, { password = it }, placeholder = { Text("Пароль") })

        Button({
            vm.login = login
            vm.email = email
            vm.password = password
            vm.addUser()
        }) {
            Text("Добавить")
        }
    }
}

@Composable
fun ProfileScreen(modifier: Modifier, vm: UserViewModel = viewModel(), goToUserScreen: () -> Unit){
    Column(modifier) {
        Button({ goToUserScreen() }) {
            Text("Назад")
        }
        Text("Логин: ${vm.login}")
        TextField(value = vm.email, { vm.email = it }, placeholder = { Text("Почта") })
        TextField(value = vm.password, { vm.password = it }, placeholder = { Text("Пароль") })

        Button({
            vm.changeUserByLogin(vm.login,vm.email,vm.password)
        }) {
            Text("Сохранить")
        }
    }
}

@Composable
fun ChangeScreen(modifier: Modifier, vm: UserViewModel = viewModel(), goToUserScreen: () -> Unit){

}