package com.example.labwork26

import android.provider.ContactsContract
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.labwork26.data.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class UserViewModel : ViewModel() {
    var users = mutableStateListOf<User>()

    var login by mutableStateOf("")
    var email by mutableStateOf("")
    var password by mutableStateOf("")

    fun addUser(){
        users.add(User(login, password, email))
    }

    fun changeUserByLogin(login: String,email: String,password: String)
    {
        users.forEach { user ->
            if (user.login == login)
            {
                user.email = email
                user.password = password
                return
            }
        }
    }
    fun removeUserByLogin(login: String)
    {
        val user = users.first { user -> user.login == login }
        if (user != null) {
            users.remove(user)
        }
    }
    fun getUserByLogin(login : String)
    {
        val user = users.first { user -> user.login == login }
        if (user != null) {
            this.login = user.login
            email = user.email
            password = user.password
        }
    }
}
