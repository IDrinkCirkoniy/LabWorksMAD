﻿using System.CommandLine;

string userFile = Path.Combine(Environment.CurrentDirectory, "user.txt");

List<User> users = GetUsers();


RootCommand root = new RootCommand("LabWork16");

Option<string> registerLoginOption = new Option<string>("--login", "--l")
{
    Description = "Логин пользователя",
};
Option<string> loginOption = new Option<string>("--login", "--l")
{
    Description = "Логин пользователя",
};
Option<string> passwordOption = new Option<string>("--password", "--pwd")
{
    Description = "Пароль пользователя",
};


Command registerCommand = new("register", "Регистрация нового пользователя")
{
    registerLoginOption,
    passwordOption
};

Command loginCommand = new("auth", "Авторизация нового пользователя")
{
    loginOption,
    passwordOption
};

root.Subcommands.Add(registerCommand);
root.Subcommands.Add(loginCommand);

registerCommand.SetAction(res =>
{
    string login = res.GetValue(registerLoginOption);
    string password = res.GetValue(passwordOption);

    Register(login, password);
    return;
});

loginCommand.SetAction(res =>
{
    string login = res.GetValue(loginOption);
    string password = res.GetValue(passwordOption);

    Login(login, password);
    return;
});

var result = root.Parse(args);

result.Invoke();



void Login(string userLogin, string userPassword)
{
    Console.WriteLine("Авторизация");
    bool isExists = false;

    bool isPasswordNotNull = userPassword is not null;
    bool isLoginNotNull = userLogin is not null;

    int attempts = 3;

    while (true)
    {
        if (!isLoginNotNull)
        {
            if (!isExists)
            {
                Console.Write("Login: ");
                userLogin = Console.ReadLine();
            }
        }

        if (!isPasswordNotNull)
        {
            Console.Write("Password: ");
            userPassword = "";

            while (true)
            {
                var key = Console.ReadKey(true);

                if (key.Key is ConsoleKey.Enter)
                {
                    break;
                }
                if (key.Key is ConsoleKey.Backspace)
                {
                    if (userPassword.Length > 0)
                        userPassword = userPassword.Remove(userPassword.Length - 1, 1);

                    continue;
                }

                userPassword += key.KeyChar;
            }
        }

        foreach (User user in users)
        {
            if (user.Login == userLogin)
            {
                attempts--;
                if (attempts <= 0)
                {
                    isExists = false;
                    attempts = 3;
                }
                else
                    isExists = true;

                if (user.Password == userPassword)
                {
                    Console.WriteLine();
                    Console.WriteLine("Вы успешно вошли");
                    Console.ReadKey();
                    return;
                }
            }
        }
        Console.WriteLine("Неправильное имя пользователя или пароль");

        if (isPasswordNotNull)
        {
            Console.ReadKey();
            return;
        }
    }
}

List<User> GetUsers()
{
    string login;
    string password;

    List<User> users = new List<User>();
    if (!File.Exists(userFile))
        File.Create(userFile);

    string[] info = File.ReadAllLines(userFile);

    for (int i = 0; i < info.Length / 2; i++)
    {
        login = info[0 + i * 2];
        password = info[1 + i * 2];

        users.Add(new User(login, password));
    }
    return users;
}

void Register(string login, string password)
{
    Console.WriteLine("Регистрация");
    if (login is null)
    {
        Console.Write("Login: ");
        login = Console.ReadLine();
    }

    if (password is null)
    {
        Console.Write("Password: ");
        password = Console.ReadLine();
    }

    if (!File.Exists(userFile))
        File.Create(userFile);

    if (users.FindIndex(u => u.Login == login) == -1)
    {
        string[] info = [login, password];

        File.AppendAllLines(userFile, info);

        Console.WriteLine("Успешная регистрация");
        Console.ReadKey();
    }
    else
    {
        Console.WriteLine("Пользователь уже существует");
        Console.ReadKey();
    }
}
