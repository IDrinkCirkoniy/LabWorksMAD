﻿using ChatClient;
using Microsoft.AspNetCore.SignalR.Client;
using System.Windows;

namespace LabWork27
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private HubConnection _connection { get; set; }
        private string _userName;
        private string _roomName;
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            await ConnectToServer();
        }

        private async void SendMessageButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(MessageTextBox.Text))
                return;

            await _connection.InvokeAsync("Send", MessageTextBox.Text);
            MessageTextBox.Text = "";
        }

        private async void ConnectMenuItem_Click(object sender, RoutedEventArgs e)
        {
            await ConnectToServer();
        }

        private async Task ConnectToServer()
        {
            LoginWindow loginWindow = new();
            loginWindow.Owner = this;
            loginWindow.ShowDialog();
            if (loginWindow.DialogResult == true)
            {
                if (_connection is not null)
                    await _connection.StopAsync();

                SendMessageButton.IsEnabled = true;

                Title = $"Имя пользователя: {loginWindow.UserName} Комната: {loginWindow.RoomName}";
                _userName = loginWindow.UserName;
                _roomName = loginWindow.RoomName;

                _connection = new HubConnectionBuilder().WithUrl("http://localhost:5192/chat").Build();

                _connection.On<string, string>("Receive", (user, message) =>
                {
                    Dispatcher.Invoke(() => { MessagesTextBox.Text += $"\n{user}: {message}"; });
                });

                await _connection.StartAsync();
                await _connection.InvokeAsync("JoinRoom", _roomName, _userName);

                MessagesTextBox.Text += $"\nПодключено к комнате {_roomName} с именем {_userName}";
            }
            else
            {
                if (_connection is null || _connection.State == HubConnectionState.Disconnected)
                {
                    Title = "";
                    SendMessageButton.IsEnabled = false;
                }
            }
        }
    }
}