﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace LabWork27
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
