﻿using Microsoft.AspNetCore.SignalR;
using System.Collections.Concurrent;

namespace ChatServer
{
    public class ChatHub : Hub
    {
        private static ConcurrentDictionary<string, string> _connectionToRoom = new();
        private static ConcurrentDictionary<string, string> _connectionToUser = new();

        public async Task Send(string message)
        {
            var connectionId = Context.ConnectionId;

            if (_connectionToRoom.TryGetValue(connectionId, out var room) && _connectionToUser.TryGetValue(connectionId, out var user))
            {
                await Clients.Group(room).SendAsync("Receive", user, message);
            }
        }
        public async Task JoinRoom(string roomName, string userName)
        {
            var connectionId = Context.ConnectionId;

            _connectionToRoom[connectionId] = roomName;
            _connectionToUser[connectionId] = userName;

            await Groups.AddToGroupAsync(connectionId, roomName);
        }
        public override Task OnDisconnectedAsync(Exception? exception)
        {
            var connectionId = Context.ConnectionId;

            if (_connectionToRoom.TryGetValue(connectionId, out var room))
            {
                return Groups.RemoveFromGroupAsync(connectionId, room);
            }
            else return null;
        }
    }
}
