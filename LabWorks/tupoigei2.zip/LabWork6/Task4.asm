%include "io64.inc"
section .data
string db "my strings", 0
symbol db '',0

section .text
global main
main:
    mov rbp, rsp; for correct debugging
    
    PRINT_STRING "INPUT SYMBOL: "
    GET_CHAR symbol
    
    mov rdi, string
    mov rsi, rdi 
    mov al, [symbol]    
    mov rcx, -1   
    repne scasb  
    sub rdi, string     
    mov rax, 60

    PRINT_STRING "POSITION: "
    PRINT_DEC 8, rdi

    xor rax, rax
    ret