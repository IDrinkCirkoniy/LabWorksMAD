%include "io64.inc"
section .data
string db "", 0

section .text
global main
main:
    mov rbp, rsp; for correct debugging
    
    PRINT_STRING "INPUT STRING: "
    GET_STRING [string], 21
      
    mov rdi, string
    mov rsi, rdi 
    mov al, 0    
    mov rcx, -1   
    repne scasb  
    sub rdi, string  
    dec rdi    
    mov rax, 60

    PRINT_STRING "LENGTH: "
    PRINT_DEC 8, rdi

    xor rax, rax
    ret