%include "io64.inc"
section .data
str1 db "Hello Worldd", 0
str1_len dd 13         ; длина первой строки 
str2 db "",12 , 0
str2_len dd 13          ; длина второй строки
 
section .text
global main
main:
    mov rbp, rsp; for correct debugging
    PRINT_STRING "INPUT STRING: "
    GET_STRING str2, 12

    mov rsi, str1
    mov rdi, str2

    repe cmpsb      ; сравниваем байты
    jnz notequal    ; если не равны
 
    mov rcx, str1_len
    cmp rcx, str2_len   ; если равны, сравниваем длины строк
    jnz notequal
    mov rdi, 16          ; если строки равны
    jmp exit
    
    
notequal:
    PRINT_STRING "inc"
    xor rax,rax
    ret
exit:
    PRINT_STRING "cor"
    xor rax,rax
    ret