%include "io64.inc"
section .data
    text db "hi wrld"
    length dd 9
section .bss
    target resb 9
section .text
global main
main:
    mov rbp, rsp; for correct debugging
    mov rsi, text
    add rsi, 8
    mov rdi, target
    add rdi, 8
    mov rcx, [length]
    std
    rep movsb
    
    PRINT_STRING  target
    xor rax, rax
    ret