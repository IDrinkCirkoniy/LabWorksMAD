%include "io64.inc"
section .data
    s1 db "priv bro"
    i dd 0
    n dd 0
section .bss
    s2 resb 9
section .text

global main
main:
    mov rbp, rsp; for correct debugging
    PRINT_STRING "INPUT I: "
    GET_DEC 8, i
    PRINT_STRING "INPUT LENGTH: "
    GET_DEC 8, n
    
    mov rsi, s1
    mov eax, [i]
    add rsi, rax
    mov rdi, s2
    mov rcx, [n]
    rep movsb
    
    PRINT_STRING s2
    xor rax, rax
    ret