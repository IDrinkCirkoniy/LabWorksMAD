﻿using System.Net;
using System.Net.Sockets;
using System.Text;

IPEndPoint ip = new IPEndPoint(IPAddress.Any, 8888);

var tcpListener = new TcpListener(ip);
string format = "HH:mm:ss dd.MM.yyyy";

List<TcpClient> clients = new List<TcpClient>();
try
{
    tcpListener.Start();
    Console.WriteLine("Жду соединений");


    while (true)
    {
        clients.Add(tcpListener.AcceptTcpClient());
        foreach (TcpClient tcpClient in clients)
        {
            if (!tcpClient.Connected)
                continue;

            byte[] buffer = new byte[512];
            var stream = tcpClient.GetStream();

            int received = stream.Read(buffer);

            string data = Encoding.UTF8.GetString(buffer, 0, received);

            string[] info = data.Split('\n');

            Console.WriteLine($"{info[0]}: {info[1]} ({DateTime.Now.ToString(format)})");
            stream.Flush();
            stream.Close();
        }
    }

}

catch (Exception ex)
{
    Console.WriteLine(ex.Message);
    Console.ReadKey();
}
