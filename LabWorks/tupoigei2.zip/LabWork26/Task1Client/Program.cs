﻿using System.Net;
using System.Net.Sockets;
using System.Text;

IPEndPoint ip = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8888);

var tcpClient = new TcpClient();

try
{
    tcpClient.Connect(ip);
    while (true)
    {
        byte[] buffer = new byte[512];
        var stream = tcpClient.GetStream();

        int received = stream.Read(buffer);

        if (received == 0)
            continue;

        string message = Encoding.UTF8.GetString(buffer, 0, received);

        Console.WriteLine(message);
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
finally
{
    tcpClient.Close();
}