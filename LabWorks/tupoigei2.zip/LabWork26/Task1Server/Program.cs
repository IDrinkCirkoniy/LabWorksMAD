﻿using System.Net;
using System.Net.Sockets;
using System.Text;

IPEndPoint ip = new IPEndPoint(IPAddress.Any, 8888);

var tcpListener = new TcpListener(ip);

try
{
    tcpListener.Start();
    while (true)
    {
        using var tcpClient = tcpListener.AcceptTcpClient();

        while (true)
        {
            var stream = tcpClient.GetStream();


            byte[] data = Encoding.UTF8.GetBytes($"сообщение: {DateTime.Now}");
            stream.Write(data);

            Console.WriteLine("хоп отправили");
            stream.Flush();

            Thread.Sleep(5000);
        }
        
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
finally
{
    tcpListener.Stop();
}
