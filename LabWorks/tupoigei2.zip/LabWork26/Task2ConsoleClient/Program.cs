﻿using System.Net;
using System.Net.Sockets;
using System.Text;

IPEndPoint ip = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8888);



Console.Write("Введите имя: ");
string username = Console.ReadLine();

try
{
    while (true)
    {
        Console.Write("Введите сообщение: ");

        string message = Console.ReadLine();

        var tcpClient = new TcpClient();
        tcpClient.Connect(ip);
        var stream = tcpClient.GetStream();

        byte[] data = Encoding.UTF8.GetBytes($"{username}\n{message}");
        stream.Write(data);

        stream.Flush();

        tcpClient.Close();
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
